jQuery(function($) {
    $('.content-list-btn').click(function() {
        $('.content-list').toggleClass('expand');
    });
});





var locations =
[
       {title: 'Park Ave Penthouse',location: {lat:40.7713024, lng: -73.9632393}},

       {title: 'Chelsea Loft',location: {lat:40.7444883, lng: -73.9949465}},
       {title: 'Union Square Open Floor Plan',location: {lat:40.7347062, lng: -73.9895759}},
       {title: 'Chinatown Honey Space',location: {lat:40.7180628, lng: -73.9961237}},
	];
//creates map
	var map;
    //initialise map
	function initMap(){
		map = new google.maps.Map(document.getElementById('map'),{
			center: {lat:40.7413549, lng: -73.9980244},
			zoom: 13
		}); 
		ko.applyBindings(new viewModel());
	}

     var markers = [];
	var viewModel = function(){
		/*/var largeInfowindow = new google.maps.InfoWindow();
		this.search=ko.observable('');
		this.places=ko.observableArray([]);
		map = new google.maps.Map(document.getElementById('map'),{
			center: {lat:40.7413549, lng: -73.9980244},
			zoom: 13
		});
		locations.forEach(function(loc){
			this.places.push(new place(loc));

		});*/
		var self = this;
    self.locationList = ko.observableArray(locations);
    self.title = ko.observable('');
    self.navigation = ko.observable();

    self.currentMarker = function(current_location) {
        toggleBounce(current_location.marker);
        google.maps.event.trigger(current_location.marker, 'click');
    };
    self.query = ko.observable('');
    self.search = ko.computed(function() {
        // Make the filter-search case insensitive
        var userInput = self.query().toLowerCase();

        return ko.utils.arrayFilter(self.locationList(), function(item) {
            var title = item.title.toLowerCase();
            var userInputIsInTitle = title.indexOf(userInput) >= 0;
            if (item.marker) {
                // toggle visibility of the marker
                item.marker.setVisible(userInputIsInTitle);
            }
            return userInputIsInTitle;
        });
    });




    //Initialize the InfoWindow
    var largeInfowindow = new google.maps.InfoWindow();
    // Marker styling
    var defaultIcon = makeMarkerIcon('FF0000');
   
    // Applying bounds inorder to limit the display of locations on the map
    var bounds = new google.maps.LatLngBounds();

    // Populate Window
    function populateWindow() {
            populateInfoWindow(this, largeInfowindow);
            
        }


    // Setting the default colour of marker
    function setDefaultIcon() {
            this.setIcon(defaultIcon);
        }


  
  for (var i = 0; i < locations.length; i++){
 	var position = locations[i].location;
 	var title = locations[i].title;

 	var marker = new google.maps.Marker({
 		map:map,
 		position:position,
 		title:title,
 		animation: google.maps.animation.DROP,
 		icon:defaultIcon
 		id:i

 	});
    markers.push(marker);

    
 
        markers.push(marker);
        
        self.locationList()[i].marker = marker;

        // Create an onclick event to open the infowindow at each marker.
        marker.addListener('click', populateWindow);

       

        // Extend the boundaries of the map for each marker and display the marker
        bounds.extend(markers[i].position);
    }
    //make sure all of the markers fit within the map bounds
    map.fitBounds(bounds);
};


// This function populates the infowindow when the marker is clicked.

function populateInfoWindow(marker, infowindow) {
    // Making sure the infowindow is not already opened on the selected marker.
    if (infowindow.marker != marker) {
        
        infowindow.setContent('');
        infowindow.marker = marker;
        // Marker property is cleared when the infowindow is closed.
        infowindow.addListener('closeclick', function() {
            infowindow.marker = null;
        });

        //Declaring streetViewService and radius
        var streetViewService = new google.maps.StreetViewService();
        var radius = 50;

        // Streetview function
        var getStreetView= function getStreetView(data, status) {
        /* First checking the status to be "OK" to make sure that the streetview is found on the given location */
            if (status == google.maps.StreetViewStatus.OK) {
                var nearStreetViewLocation = data.location.latLng;
                var heading = google.maps.geometry.spherical.computeHeading(
                    nearStreetViewLocation, marker.position);
                var panoramaOptions = {
                    position: nearStreetViewLocation,
                    pov: { //pov:-> point of view
                        heading: heading,
                        pitch: 30 //slightly above the building
                    }
                };
                //getting Panaroma and putting it inside the div having id= "streetview"
                var panorama = new google.maps.StreetViewPanorama(
                    document.getElementById('streetview'), panoramaOptions);
            } else {
                     alert("No StreetView Found");
            }
        };

        // code for wikipedia ajax request.
        var wikiURL = 'https://en.wikipedia.org/w/api.php?action=opensearch&search=' + marker.title + '&format=json&callback=wikiCallback';
        var wikiTimeoutRequest = setTimeout(function() {
            // Setting the error message if wikipedia resource is not available within time period
			alert("Failed to load wikipedia resources \n Please try later !!");
        }, 8000);
        $.ajax({
            url: wikiURL,
            dataType: "jsonp",
            success: function(response) {

                // getting the URL from wiki response;
                var URL = response[3];
                // Using streetview service to get the closest streetview image
                streetViewService.getPanoramaByLocation(marker.position, radius, getStreetView);
                /* setting the infowindow content to have the place name, wikipedia link(if available) and streetview(if available) */
                infowindow.setContent('<div class= "infoWindow_title">' + marker.title + '</div><div id= "url-div"></div><a class="place-url" href ="' + URL + '">' + URL + '</a><div id="streetview"></div>');
                // Open the infowindow on the correct marker.
                infowindow.open(map, marker);
                console.log(URL);
                clearTimeout(wikiTimeoutRequest);
                // Setting the error message if wikipedia resource is not available on selected location
                if(URL.length === 0){
                    infowindow.setContent('<div class= "infoWindow_title">' + marker.title + '</div><div id= "url-div">No wikipedia resource found</div><div id="streetview"></div>');
                }
            }
        });
    }
}

